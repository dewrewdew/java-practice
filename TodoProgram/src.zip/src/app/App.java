package app;
import controller.*;

public class App {
    public static void main(String[] args) {

        new Controller().run();
    }
}
